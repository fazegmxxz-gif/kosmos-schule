 "use client";
import {createContext,useContext,useEffect,useState,ReactNode} from "react";
export type Role="schueler"|"lehrer"|"admin";
export type Lesson={id:string;klasse:string;fach:string;lehrer:string;raum:string;tag:number;start:string;ende:string;farbe:string};
export type Task={id:string;klasse:string;fach:string;titel:string;faellig:string;erledigt:boolean};
export type EventItem={id:string;titel:string;datum:string;zeit:string;ort:string};
export type Message={id:string;von:string;an:string;text:string;datum:string};
export type Data={user:{name:string;role:Role;klasse?:string}|null;classes:string[];lessons:Lesson[];tasks:Task[];events:EventItem[];messages:Message[]};
const seed:Data={
 user:null,classes:["9.6"],
 lessons:[
 {id:"1",klasse:"9.6",fach:"Mathematik",lehrer:"Herr Weber",raum:"204",tag:0,start:"08:00",ende:"09:30",farbe:"#4f7cff"},
 {id:"2",klasse:"9.6",fach:"Deutsch",lehrer:"Frau Keller",raum:"105",tag:0,start:"09:45",ende:"11:15",farbe:"#e85aad"},
 {id:"3",klasse:"9.6",fach:"Englisch",lehrer:"Frau Moore",raum:"110",tag:1,start:"08:00",ende:"09:30",farbe:"#8b6cff"},
 {id:"4",klasse:"9.6",fach:"Informatik",lehrer:"Herr Lang",raum:"PC-1",tag:2,start:"10:00",ende:"11:30",farbe:"#23ad7b"},
 {id:"5",klasse:"9.6",fach:"Biologie",lehrer:"Frau Roth",raum:"Labor",tag:3,start:"08:00",ende:"09:30",farbe:"#35a85b"},
 {id:"6",klasse:"9.6",fach:"Sport",lehrer:"Herr Brandt",raum:"Halle",tag:4,start:"09:00",ende:"10:30",farbe:"#e7a126"}],
 tasks:[
 {id:"t1",klasse:"9.6",fach:"Mathematik",titel:"Übungsblatt 12",faellig:"2026-10-07",erledigt:false},
 {id:"t2",klasse:"9.6",fach:"Deutsch",titel:"Gedicht interpretieren",faellig:"2026-10-09",erledigt:false}],
 events:[
 {id:"e1",titel:"Schulfest",datum:"2026-10-16",zeit:"15:00",ort:"Schulhof"},
 {id:"e2",titel:"Fußballturnier",datum:"2026-10-23",zeit:"09:00",ort:"Sportplatz"}],
 messages:[{id:"m1",von:"Sekretariat",an:"9.6",text:"Willkommen im Kosmos-Schulportal.",datum:"2026-10-01"}]};
const Ctx=createContext<{d:Data;set:(f:(d:Data)=>Data)=>void;ready:boolean}>(null as any);
export function Provider({children}:{children:ReactNode}){const[d,setD]=useState(seed);const[ready,setReady]=useState(false);
useEffect(()=>{try{const s=localStorage.getItem("kosmos-demo");if(s)setD(JSON.parse(s))}catch{}setReady(true)},[]);
useEffect(()=>{if(ready)localStorage.setItem("kosmos-demo",JSON.stringify(d))},[d,ready]);
return <Ctx.Provider value={{d,set:setD,ready}}>{children}</Ctx.Provider>}
export const useStore=()=>useContext(Ctx);