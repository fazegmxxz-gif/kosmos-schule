# Kosmos Schule – Demo 9.6

Demo für Klasse 9.6. Start: npm install, danach npm run dev.

Enthält Dashboard, Stundenplan, Schulkalender, Aufgaben, Klasse, Nachrichten und eine kleine Admin-Demo.
Noch keine echten Benutzerkonten oder gemeinsame Datenbank.
